/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import model.Contacts;
import model.Countries;
import model.Customer;
import model.FirstLevelDivisions;
import model.User;

/**
 * Methods for accessing database data.
 * This class allows access to the database to retrieve information.
 * @author lucytran
 */
public class dbData {

  

    /**
     * Division/ State List.
     * List of divisions for customer combo box.
     */
    static ObservableList<FirstLevelDivisions> divisionList = FXCollections.observableArrayList();
    
    /**
     * Country List.
     * List of countries for customer combo box.
     */
    static ObservableList<Countries> countryList = FXCollections.observableArrayList();

    /**
     * Contact List.
     * List of contacts for add/edit appointment.
     */
    static ObservableList<Contacts> contactsList = FXCollections.observableArrayList();
    
    /**
     * Type List.
     * List of types for add/edit appointment.
     */
    static ObservableList<Appointment> typeList = FXCollections.observableArrayList();

    /**
     * User Name List.
     * List of user names for add/edit appointment.
     */
    static ObservableList<User> userNamesList = FXCollections.observableArrayList();
    
    /**
     * Customer Name List.
     * List of customer names for add/edit appointment.
     */
    static ObservableList<Customer> customerNamesList = FXCollections.observableArrayList();

    /**
     * Month Table.
     * List to populate appointment table by appointment month.
     */
    static ObservableList<Appointment> monthTable = FXCollections.observableArrayList();
   
    /**
     * Week Table.
     * List to populate appointment table by appointment week.
     */
    static ObservableList<Appointment> weekTable = FXCollections.observableArrayList();

    /**
     * Schedule Table.
     * List to populate schedule table in report window.
     */
    static ObservableList<Appointment> scheduleTable = FXCollections.observableArrayList();
   
    /**
     * Month Report.
     * List to populate month table in report window.
     */
    static ObservableList<Appointment> monthReport = FXCollections.observableArrayList();

    /**
     * All Customers.
     * List of all customers from database.
     */ 
    static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
    
    /**
     * All customers with existing appointments.
     * List of all customers with existing appointments
     */
    static ObservableList<Customer> existingA = FXCollections.observableArrayList();
 
    /**
     * All Appointments.
     * List of all appointments from database.
     */
    static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
    
    /**
     * All Customer Total.
     * List of the total number of customers in the database.
     */
    static ObservableList allCTotal = FXCollections.observableArrayList();

    static Appointment appointment;
    User userName;

 
    /**
     * Method for 15 minute alert.
     * This method retrieves for user  an upcoming appointment if exists.
     * @return appointmentID and appointment start date and time.
     */
    public static Appointment upcoming()
    {
       
        LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());
        ZonedDateTime zdt = now.atZone(ZoneId.systemDefault());
        LocalDateTime conv = zdt.withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime();
        LocalDateTime up = conv.plusMinutes(15);
        
        try
        {   
            String sql = "SELECT * FROM appointments "
                    + "JOIN users ON appointments.User_ID = users.User_ID "
                    + "WHERE Start BETWEEN ? AND ?  AND users.User_Name = ?";

            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);
            
            ps.setObject(1, conv);
            ps.setObject(2, up);
            ps.setString(3, dbUser.getUser().getUserName());
            
            ResultSet rs  = ps.executeQuery();
            
            if(rs.next())
            {
                
                appointment = new Appointment
                        (rs.getInt("Appointment_ID"), 
                        rs.getTimestamp("Start").toLocalDateTime());
                
                return appointment;
            }           
        }
        
       catch(SQLException e)
       {
           e.printStackTrace();
       }
       return null;      
    }
    
   
//_________________________________________________________________________________________________________//
//***********TABLES***|***FOR MAIN*************//
   
    /**
     * Method for Month Table.
     * This method gets all the information for appointment table sorted by the appointment's month.
     * @return monthTable
     */
    public static ObservableList<Appointment> MonthTable() {
        monthTable.clear();
        try {
            Statement s = dbConnect.getConnect().createStatement();
            String query = "SELECT appointments.*, "
                    + "contacts.Contact_Name, users.User_Name, customers.Customer_Name "
                    + "FROM appointments "
                    + "JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID "
                    + "JOIN users ON appointments.User_ID = users.User_ID "
                    + "JOIN customers ON appointments.Customer_ID = customers.Customer_ID "
                    + "WHERE MONTHNAME(appointments.Start) = MONTHNAME(now()) "
                    + "ORDER BY appointments.Start ASC";
             
                    
            
            ResultSet result = s.executeQuery(query);

            while (result.next()) {
                Appointment appointment = new Appointment(
                        result.getInt("Appointment_ID"),
                        result.getString("Title"),
                        result.getString("Description"),
                        result.getString("Location"),
                        result.getString("Type"),
                        result.getTimestamp("Start").toLocalDateTime(),
                        result.getTimestamp("End").toLocalDateTime(),
                        result.getString("Contact_Name"),
                        result.getString("Customer_Name"),
                        result.getString("User_Name"));

                monthTable.addAll(appointment);

            }
            s.close();
            return monthTable;

        } catch (SQLException e) {
            System.out.println("Error for Month Table..." + e.getMessage());
        }
        return null;
    }

    /**
     * Method for Week Table.
     * This method gets all the information for appointment table sorted by the appointment's week.
     * @return weekTable
     */
    public static ObservableList<Appointment> WeekTable() {
        weekTable.clear();
        try {
            Statement statement = dbConnect.getConnect().createStatement();
            String query = "SELECT appointments.*, "
                    + "contacts.Contact_Name, users.User_Name, customers.Customer_Name "
                    + "FROM appointments "
                    + "JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID "
                    + "JOIN users ON appointments.User_ID = users.User_ID "
                    + "JOIN customers ON appointments.Customer_ID = customers.Customer_ID "
                    + "WHERE WEEK(appointments.Start) = WEEK(now()) "
                    + "ORDER BY appointments.Start ASC";

            ResultSet result = statement.executeQuery(query);

            while (result.next()) {
                Appointment appointment = new Appointment(
                        result.getInt("Appointment_ID"),
                        result.getString("Title"),
                        result.getString("Description"),
                        result.getString("Location"),
                        result.getString("Type"),
                        result.getTimestamp("Start").toLocalDateTime(),
                        result.getTimestamp("End").toLocalDateTime(),
                        result.getString("Contact_Name"),
                        result.getString("Customer_Name"),
                        result.getString("User_Name"));

                weekTable.addAll(appointment);

            }
            statement.close();
            return weekTable;

        } catch (SQLException e) {
            System.out.println("Error for Week Table..." + e.getMessage());
        }
        return null;
    }

//_________________________________________________________________________________________________________//
//***********ADD/UPDATE/DELETE*************//  
    /**
     * Method to get all customers data from database.
     * This method retrieves the customer's ID, name, address, postal code, phone, and division ID.
     * @return allCustomers
     */
    public static ObservableList<Customer> getAllCustomer() {
        allCustomers.clear();
        try {
                String sql = "SELECT Customer_ID, Customer_Name, Address, "
                    + "Postal_Code, Phone, customers.Division_ID, Country_ID "
                    + "FROM customers, first_level_divisions "
                    + "WHERE first_level_divisions.Division_ID = customers.Division_ID ";
            
            
                PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) 
                {
                    Customer c = new Customer(
                    rs.getInt("Customer_ID"), 
                    rs.getString("Customer_Name"),
                    rs.getString("Address"),
                    rs.getString("Postal_Code"), 
                    rs.getString("Phone"),
                    rs.getInt("Division_ID"), 
                    rs.getInt("Country_ID"));
               
                
                    allCustomers.add(c);
                }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }

        return allCustomers;
    }

    /**
     * Method to add customer to the database.
     * This method inserts new customer and customer's data into the database.
     * @param customerName
     * @param address
     * @param postalCode
     * @param phone
     * @param division 
     */
    public static void addCustomer(String customerName, String address, String postalCode, String phone, FirstLevelDivisions division) {
        try {
            
            String sqlc = "INSERT INTO customers VALUES(NULL, ?, ?, ?, ?, NOW(), 'LT', NOW(), 'LT', ?)";

            PreparedStatement psac = dbConnect.getConnect().prepareStatement(sqlc);

            psac.setString(1, customerName);
            psac.setString(2, address);
            psac.setString(3, postalCode);
            psac.setString(4, phone);  
            psac.setInt(5, division.getDivisionID()); 

            psac.execute();
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }

    }

    /**
     * Method to update a customer.
     * This method updates information for an existing customer in the database.
     * @param customerID
     * @param customerName
     * @param address
     * @param postalCode
     * @param phone
     * @param division 
     */
    public static void updateCustomer(int customerID, String customerName, String address, String postalCode, String phone, FirstLevelDivisions division) {
        try {

            String sqlud = "UPDATE customers SET Customer_Name = ?, Address = ?, "
                    + "Postal_Code = ?, Phone = ?, Division_ID = ? "
                    + "WHERE Customer_ID = ?";

            PreparedStatement psud = dbConnect.getConnect().prepareStatement(sqlud);

            psud.setString(1, customerName);
            psud.setString(2, address);
            psud.setString(3, postalCode);
            psud.setString(4, phone);
            psud.setInt(5, division.getDivisionID());
            psud.setInt(6, customerID);

            psud.execute();

        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    /**
     * Method to check if customer has an existing appointment.
     * This method verifies if a customer has an existing appointment.
     * @param customerID
     * @return If it is true or false that a customer has an existing appointment.
     * @throws SQLException 
     */ 
    public static boolean ExistingA(int customerID) throws SQLException {
        try {
            String sql = "SELECT customers.Customer_ID "
                    + "FROM customers "
                    + "JOIN appointments ON appointments.Customer_ID = customers.Customer_ID "
                    + "WHERE customers.Customer_ID = " + customerID;

            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            return rs.next();
        } 
        catch (SQLException e) 
        {   
            e.printStackTrace();
        }
        return true;
    }

    /**
     * Method to delete customer from database.
     * This method deletes customer and customer's data from database.
     * @param customerID 
     */
    public static void deleteCustomer(int customerID) {
        try {
           
           String sql1 = "DELETE FROM customers WHERE Customer_ID = " +customerID;
                    
            PreparedStatement ps1 = dbConnect.getConnect().prepareStatement(sql1);
            
            ps1.execute();            
        } 
        catch (SQLException e)
        {
            e.printStackTrace();   
        }
    }

 
    /**
     * Method to get all appointments in the database.
     * This method retrieves all appointments from the database.
     * @return allAppointments
     */
    public static ObservableList<Appointment> getAllAppointment() {
        allAppointments.clear();

        try {
            Statement statement = dbConnect.getConnect().createStatement();
            String query = "SELECT "
                    + "appointments.Appointment_ID,"
                    + "appointments.Title,"
                    + "appointments.Description,"
                    + "appointments.Location,"
                    + "appointments.Type,"
                    + "appointments.Start,"
                    + "appointments.End,"
                    + "contacts.Contact_Name,"
                    + "users.User_Name,"
                    + "customers.Customer_Name "
                    + "FROM (((appointments "
                    + "JOIN users ON appointments.User_ID = users.User_ID)"
                    + "JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID)"
                    + "JOIN customers ON appointments.Customer_ID = customers.Customer_ID)";

            ResultSet result = statement.executeQuery(query);

            while (result.next()) {

                Appointment appointment = new Appointment(
                        result.getInt("Appointment_ID"),
                        result.getString("Title"),
                        result.getString("Description"),
                        result.getString("Location"),
                        result.getString("Type"),
                        result.getTimestamp("Start").toLocalDateTime(),
                        result.getTimestamp("End").toLocalDateTime(),
                        result.getString("Contact_Name"),
                        result.getString("Customer_Name"),
                        result.getString("User_Name"));
                    
                    allAppointments.addAll(appointment);
              
                     
             

            }
            statement.close();
            return allAppointments;

        } 
        catch (SQLException e) 
        {
            System.out.println("Error for Appointment Table..." + e.getMessage());
        }
        return null;
    }
    
    /**
     * Method to add appointment to database.
     * This method inserts new appointment and appointment's data into the database.
     * @param title Title
     * @param description Description
     * @param location Location
     * @param type Type
     * @param start Start Date and Time
     * @param end End Date and Time
     * @param contact ContactID
     * @param customer CustomerID
     * @param user UserID
     */
    public static void addAppointment(String title, String description,
            String location, String type, Timestamp start,
            Timestamp end, Contacts contact,
            Customer customer, User user) {

        try {
            String sql = "INSERT INTO appointments VALUES(NULL, ?, ?, ?, ?, ?, ?, NOW(), 'LT', NOW(), 'LT', ?, ?, ?)";

            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, location);
            ps.setString(4, type);
            ps.setTimestamp(5, start);
            ps.setTimestamp(6, end);
            ps.setInt(7, customer.getCustomerID());
            ps.setInt(8, user.getUserID());
            ps.setInt(9, contact.getContactID());

            ps.execute();

        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    /**
     * Method to update an appointment.
     * This method updates information for an existing appointment in the database.
     * @param title Title
     * @param description Description
     * @param location Location
     * @param type Type
     * @param start Start Date and Time
     * @param end End Date and Time
     * @param customer CustomerID
     * @param user UserID
     * @param contact ContactID
     * @param appointmentID AppointmentID
     */
    public static void updateAppointment(String title, String description,
            String location, String type, Timestamp start, Timestamp end,
            Customer customer, User user, Contacts contact, int appointmentID) {
        try {
            String sql3 = "UPDATE appointments "
                    + "SET "
                    + "Title = ?, Description = ?, "
                    + "Location = ?, Type = ?, Start = ?, End = ?, "
                    + "Customer_ID = ?, User_ID = ?, Contact_ID = ? "
                    + "WHERE Appointment_ID = ?";

            PreparedStatement ps3 = dbConnect.getConnect().prepareStatement(sql3);

            ps3.setString(1, title);
            ps3.setString(2, description);
            ps3.setString(3, location);
            ps3.setString(4, type);
            ps3.setTimestamp(5, start);
            ps3.setTimestamp(6, end);
            ps3.setInt(7, customer.getCustomerID());
            ps3.setInt(8, user.getUserID());
            ps3.setInt(9, contact.getContactID());
            ps3.setInt(10, appointmentID);

            ps3.execute();

        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }

    }

    /**
     * Method to delete appointment from database.
     * This method deletes appointment and appointment's data from database.
     * @param appointmentID AppointmentID from selected appointment
     */
    public static void deleteAppointment(int appointmentID) {
     

        try {
            String sql = "DELETE appointments.* FROM appointments "
                    + "WHERE Appointment_ID = " + appointmentID ;
            

            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);

            ps.execute();
            
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }

    }

//_________________________________________________________________________________________________________//
//***********REPORT*************//
    /**
     * Method for Schedule Table.
     * This method gets the schedule for each contact name in the database. 
     * The schedule for each contact contains the appointment ID, title, description, location, type, start, and end.
     * @return scheduleTable
     */
    public static ObservableList<Appointment> ScheduleTable() {
        scheduleTable.clear();
        try {
            String query = "SELECT "
                    + "CONCAT_WS('\n', Appointment_ID, Title, "
                    + "Description, Location, Type, "
                    + "Customer_ID) AS schedule, "
                    + "Start, End, "
                    + "contacts.Contact_Name "
                    + "FROM (appointments "
                    + "JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID)";
            
            PreparedStatement ps = dbConnect.getConnect().prepareStatement(query);
            
            ResultSet result = ps.executeQuery();

            while (result.next()) 
            {
                Appointment appointment = new Appointment(
                        result.getString("schedule"),
                        result.getString("Contact_Name"),
                        result.getTimestamp("Start").toLocalDateTime(),
                        result.getTimestamp("End").toLocalDateTime());
              

                scheduleTable.addAll(appointment);
            }
            
        } catch (SQLException e) {
            System.out.println("Error for Schedule Table... " + e.getMessage());
        }
        return scheduleTable;
    }

    public static ObservableList<Appointment> Time(int contactID)
    {
        ObservableList time = FXCollections.observableArrayList();
        
        try
        {
            String query = "SELECT Start, End FROM appointments "
                    + "WHERE Contact_ID = ?";
           
            
            PreparedStatement ps = dbConnect.getConnect().prepareStatement(query);
            
            ps.setInt(1, contactID);
           
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                LocalDateTime s = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime t = rs.getTimestamp("End").toLocalDateTime();
                
                time.add(s);
                time.add(t);
                
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        return time;
    }
    /**
     * Method for Month and Type customer count.
     * This method gives the count for the number of customers for each type during each month.
     * @return monthReport
     */
    public static ObservableList<Appointment> MonthReport() {
        monthReport.clear();
        try {
            Statement statement = dbConnect.getConnect().createStatement();
            String query = "SELECT Type, MONTHNAME(Start) AS month, "
                    + "COUNT(*) AS count "
                    + "FROM appointments "
                    + "GROUP BY MONTHNAME(Start), Type ";
                  
            ResultSet result = statement.executeQuery(query);

            while (result.next()) {
                String month = result.getString("month");
                String type = result.getString("type");
                int total = result.getInt("count");

                Appointment appointment = new Appointment(month, type, total);

                monthReport.addAll(appointment);

            }
            statement.close();
            return monthReport;
        } catch (SQLException e) {
            System.out.println("Error! " + e.getMessage());
        }
        return null;
    }

    /**
     * Method for total count of customers.
     * This method counts the total number of customers that exist in the database.
     * @return allCTotal
     */
    public static ObservableList<Customer> allcustTotal() {
        allCTotal.clear();
        try {
            String sql = "SELECT COUNT(Customer_Name) AS total FROM customers";

            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);

            ps.execute();

            ResultSet result = ps.executeQuery();

            while (result.next()) {
                int allTotal = result.getInt("total");

                allCTotal.add(allTotal);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allCTotal;
    }

//_________________________________________________________________________________________________________//
//***********COMBO-BOX*************//
    
    /**
     * Method for Types list.
     * This method strings the data for type.
     * @return  De-Briefing, Planning Session, Analysis
     */
    public static ObservableList<String> TypeList() //own data type 
    {
        return FXCollections.observableArrayList("De-Briefing", "Planning Session", "Analysis");
    }

    /**
     * Method for Contacts list.
     * This method contains the list of all contacts in the database.
     * @return contactsList
     */
    public static ObservableList<Contacts> ContactList() {
        contactsList.clear();
        try {
            Statement statement = dbConnect.getConnect().createStatement();
            String query = "SELECT * FROM contacts";

            ResultSet result = statement.executeQuery(query);

            while (result.next()) {
                Contacts contact = new Contacts(result.getInt("Contact_ID"),
                        result.getString("Contact_Name"),
                        result.getString("Email"));

                contactsList.addAll(contact);
            }
            statement.close();
            return contactsList;
        } catch (SQLException e) {
            System.out.println("Error! " + e.getMessage());
        }
        return null;
    }

    /**
     * Method for Countries list.
     * This method contains the list of all countries in the database.
     * @return countryList
     */
    public static ObservableList<Countries> CountryList() {
        
        try {
            String query = "SELECT Country_ID, Country FROM countries ";
            
            PreparedStatement ps = dbConnect.getConnect().prepareStatement(query);

            ResultSet result = ps.executeQuery();

            while (result.next()) {
                Countries country = new Countries(
                        result.getInt("Country_ID"),
                        result.getString("Country"));

                countryList.addAll(country);
            }
            return countryList;

        } catch (SQLException e) {
            System.out.println("Error! " + e.getMessage());
        }
        return null;
   
    }

    /**
     * Method for Divisions list.
     * This method contains the list of all the divisions based on the country selected.
     * By matching the Country ID to the correct divisions.
     * @param countryID
     * @return divisionList
     */  
    public static ObservableList<FirstLevelDivisions> DivisionsList(int countryID) {
      
        divisionList.clear();
        try {
            
            String query = "SELECT * FROM first_level_divisions "
                    + "WHERE COUNTRY_ID = ?";
            
            PreparedStatement ps = dbConnect.getConnect().prepareStatement(query);

            ps.setInt(1, countryID);
         
            ResultSet result = ps.executeQuery();

            while (result.next()) {
                FirstLevelDivisions division = new FirstLevelDivisions(
                        result.getInt("Division_ID"),
                        result.getString("Division"),
                        result.getInt("COUNTRY_ID"));

                divisionList.addAll(division);
            }
            return divisionList;
            
        } catch (SQLException e) 
        {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method for Users list.
     * This method contains the list of all users in the database.
     * @return userNamesList
     */
    public static ObservableList<User> UserList() {
        userNamesList.clear();
        try {
            Statement statement = dbConnect.getConnect().createStatement();
            String query = "SELECT * FROM users";

            ResultSet result = statement.executeQuery(query);

            while (result.next()) {
                User user = new User(result.getInt("User_ID"),
                        result.getString("User_Name"), 
                        result.getString("Password"));

                userNamesList.addAll(user);
            }
            statement.close();
            return userNamesList;
        } catch (SQLException e) {
            System.out.println("Error! " + e.getMessage());
        }
        return null;
    }


}
