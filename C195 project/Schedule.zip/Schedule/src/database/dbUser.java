/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;


import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.User;


/**
 * Method for obtaining User.
 * This method is to check whether the username and password are correct.
 * The method also logs the user's login.
 * @author lucytran
 */
public class dbUser 
{
    private static User user;
    
    /**
     * Method to get current user.
     * This method sets the user that is entering the system.
     * @return user
     */
    public static User getUser()
    {
        return user;
    }

    /**
     * Method to get the user logging in.
     * This method is determines the user entering the database and keeping track of the time and location as well as the success or failure of login.
     * @param userName user
     * @param password password
     * @return
     * @throws IOException 
     */
    public static Boolean login(String userName, String password) throws IOException
    {
        try
        {
            String sql = "SELECT * FROM users "
                    + "WHERE User_Name = ? "
                    + "AND Password = ?";
            
            PreparedStatement ps = dbConnect.getConnect().prepareStatement(sql);
            
            ps.setString(1, userName);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
            {
                user = new User();
                user.setUserName(rs.getString("User_Name"));
                Logger.log(userName, true);
                
                return true;
                
            }
            else
            {
                Logger.log(userName, false);
                return false;
            }
  
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }
}