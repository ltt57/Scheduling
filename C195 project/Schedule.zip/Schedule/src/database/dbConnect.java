/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Methods for connecting and disconnecting to the database.
 * This class is used to get access to the database and its containing information.
 * @author lucytran
 */
public class dbConnect 
{
    private static final String dbName = "WJ07mJn";
    private static final String url = "jdbc:mysql://wgudb.ucertify.com/" + dbName;
    private static final String userID = "U07mJn";
    private static final String password = "53689071397";
    private static final String jdbcDriver = "com.mysql.jdbc.Driver";
    
    
    private static Connection connect;
    
    /**
     * This method gets the connection to the database.
     * @return connect
     * @throws SQLException 
     */
    public static Connection getConnect() throws SQLException
    {        
        return connect;
    }
    
    /**
     * This method makes the connection to the database.
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws Exception 
     */
    public static void makeConnect() throws ClassNotFoundException, SQLException, Exception
    {
        //Register Driver
        Class.forName(jdbcDriver);
        connect=(Connection) DriverManager.getConnection(url, userID, password);
        
        System.out.println("Connected Successfully.");  
    }
    
    /**
     * This method closes the connection to the database 
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws Exception 
     */
    public static void closeConnect() throws ClassNotFoundException, SQLException, Exception
    {
        connect.close();
       
        System.out.println("Disconnected Successfully.");
    }
   
}
