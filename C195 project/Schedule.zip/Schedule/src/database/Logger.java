/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.ZonedDateTime;

/**
 * Methods for login activity.
 * This method records the login activity of a user.
 * @author lucytran
 */
public class Logger
{
  
    private static final String File = "login_activity.txt";
    
    public Logger() {}
    
    
    public static void log (String userName, boolean successful) throws IOException
    {
        try
        {
            FileWriter fn = new FileWriter(File, true);
            BufferedWriter bf = new BufferedWriter(fn);
            PrintWriter pw = new PrintWriter(bf);

            pw.println(ZonedDateTime.now() + " User: " + userName + (successful ? " -> Successful " : " -> Failed "));
            pw.close();
            
        }
        catch (IOException e)
        {
            System.out.println("Logger Error: " + e.getMessage());
        }
    }
    
}
