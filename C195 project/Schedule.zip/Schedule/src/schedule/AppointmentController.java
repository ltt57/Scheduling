/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbData;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import model.Appointment;
import model.Contacts;
import model.Customer;
import model.User;

/**
 * Methods for modifying an appointment.
 * This class is the controller for modifying an appointment.
 * This class provides implementations and methods for selected appointment from the Appointment table.
 * The selected appointment is then modifiable through this controller window.
 * @author lucytran
 */
public class AppointmentController implements Initializable
{
    @FXML
    private TextField StartTimeTB;
    @FXML
    private Label AppointmentLabel;
    @FXML
    private TextField EndTimeTB;
    @FXML
    private TextField AppointmentIDTB;
    @FXML
    private TextField TitleTB;
    @FXML
    private TextField DescriptionTB;
    @FXML
    private TextField LocationTB;
    @FXML
    private ComboBox<Contacts> ContactBox;
    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
    @FXML
    private ComboBox<Customer> CustomerIDBox;
    @FXML
    private ComboBox<User> UserIDBox;
    @FXML
    private Label CustomerLabel;
    @FXML
    private Label UserLabel;
    @FXML
    private ComboBox<String> TypeCB;
    @FXML
    private DatePicker DatePicker;

    
    Appointment appointment;
    boolean hr; 
    private Appointment updateAppointment = null;

    
    /**
     * This initializes the controller for modifying an appointment.
     * This method sets the title for the page and disables the ID text field.
     * The method also set prompt texts for certain text fields.
     * The method set labels for text fields.
     * @param url N/A
     * @param rb N/A
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        AppointmentLabel.setText("Edit Appointment");
        AppointmentIDTB.setDisable(true); 
        
        StartTimeTB.setPromptText("HH:MM");
        EndTimeTB.setPromptText("HH:MM");
        CustomerLabel.setText("Customer: ");
        UserLabel.setText("User: "); 
       
    }
    
    /**
     * This method sets an appointment.
     * This method is used to set the selected appointment data.
     * @param appointment This is the appointment that is being modified.
     */
    public void setAppointment(Appointment appointment)
    {
        this.appointment = appointment;    
        
       
        AppointmentIDTB.setText(Integer.toString(appointment.getAppointmentID()));
        TitleTB.setText(appointment.getTitle());
        DescriptionTB.setText(appointment.getDescription());
        LocationTB.setText(appointment.getLocation()); 
      
        
        StartTimeTB.setText(appointment.getStart().toLocalTime().toString());    
        EndTimeTB.setText(appointment.getEnd().toLocalTime().toString());    
      
        DatePicker.setValue(appointment.getStart().toLocalDate());
        
        
        //Combo-box Lists     
        TypeCB.setItems(dbData.TypeList()); 
        TypeCB.setValue(appointment.getType());      
        CustomerIDBox.setItems(dbData.getAllCustomer()); 
        UserIDBox.setItems(dbData.UserList());  
        ContactBox.setItems(dbData.ContactList()); 

        
        for(Customer cust : CustomerIDBox.getItems())
        {
            if(cust.getCustomerName().equals(appointment.getCustomerName()))
            {
                CustomerIDBox.setValue(cust);
            }
        }
        
        for(User user : UserIDBox.getItems())
        {
            if(user.getUserName().equals(appointment.getUserName()))
            {
                UserIDBox.setValue(user);
                break;
            }
        }
        
        for(Contacts contact : ContactBox.getItems())
        {
            if(contact.getContactName().equals(appointment.getContactName()))
            {
                ContactBox.setValue(contact);
            }
        }
        
       

    }

    @FXML
    private void StartTime(ActionEvent event) { 
    }


    @FXML
    private void EndTime(ActionEvent event){    
    }

    @FXML
    private void AppointmentID(ActionEvent event) {
    }

    @FXML
    private void Title(ActionEvent event) {
    }

    @FXML
    private void Description(ActionEvent event) {
    }

    @FXML
    private void Location(ActionEvent event) {
    }

    @FXML
    private void Contact(ActionEvent event) {   
    }

    @FXML
    private void Type(ActionEvent event) {
    }

    @FXML
    private void CustomerID(ActionEvent event) {       
    }

    @FXML
    private void UserID(ActionEvent event) {     
    }
    
    /**
     * Method to check for empty text fields.
     * This method checks for any empty text fields,
     * If the field is empty, the method highlights the missing component(s).
     * @return textfieldEmpty
     */
    private boolean textfieldEmpty()
    {
        boolean validTF = true;
        
        if(TitleTB.getText().isEmpty())
        {
            validTF = false;
            TitleTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Title!");  
            
            alert.showAndWait();
        }
         
        if(DescriptionTB.getText().isEmpty())
        {
            validTF = false;
            DescriptionTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Description!");  
            
            alert.showAndWait();
        }
        
        if(LocationTB.getText().isEmpty())
        {
            validTF = false;
            TitleTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Location!");  
            
            alert.showAndWait();
        }
        
        if(ContactBox.getValue() == null)
        {
            validTF = false;
            ContactBox.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Choose A Contact!");  
            
            alert.showAndWait();
        }
        
        if(TypeCB.getValue() == null)
        {
            validTF = false;
            TypeCB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Specify Type!");  
            
            alert.showAndWait();
        }
        
        if(DatePicker.getValue() == null)
        {
            validTF = false;
            DatePicker.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Choose A Start Date!");  
            
            alert.showAndWait();
        }
        
        if(StartTimeTB.getText().isEmpty())
        {
            validTF = false;
            StartTimeTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Choose A Start Time!");  
            
            alert.showAndWait();
        }
        
        if(EndTimeTB.getText().isEmpty())
        {
            validTF = false;
            EndTimeTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Choose An End Time!");  
            
            alert.showAndWait();
        }
        
        if(CustomerIDBox == null)
        {
            validTF = false;
            CustomerIDBox.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Select CustomerID!");  
            
            alert.showAndWait();
        }
        
        if(UserIDBox == null)
        {
            validTF = false;
            UserIDBox.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Select UserID!");  
            
            alert.showAndWait();
        }
        
        return validTF;    
    }

  
    @FXML
    private void Save(ActionEvent event) throws IOException 
    {
        
        int i = Integer.parseInt(AppointmentIDTB.getText());

        String title = TitleTB.getText();
        String description = DescriptionTB.getText();
        String location = LocationTB.getText();

        String type = TypeCB.getValue();        
        Customer c = CustomerIDBox.getValue();
        User u = UserIDBox.getValue();    
        Contacts co = ContactBox.getValue();

        String start = StartTimeTB.getText();
        String end = EndTimeTB.getText();
     
        LocalTime startlt = LocalTime.parse(start);
        LocalTime endlt = LocalTime.parse(end);
 
        LocalDate date = DatePicker.getValue();
        LocalDateTime startldt = LocalDateTime.of(date, startlt);
        LocalDateTime endldt = LocalDateTime.of(date, endlt);
    
        Timestamp startt = Timestamp.valueOf(startldt);
        Timestamp endt = Timestamp.valueOf(endldt);


        ZonedDateTime zdts = startldt.atZone(ZoneId.systemDefault());
        ZonedDateTime convs = zdts.withZoneSameInstant(ZoneId.of("EST"));
        LocalTime ntst = convs.toLocalTime();
        
        ZonedDateTime zdte = endldt.atZone(ZoneId.systemDefault());
        ZonedDateTime conve = zdte.withZoneSameInstant(ZoneId.of("EST"));
        LocalTime nted = conve.toLocalTime();
        
        LocalTime open = LocalTime.of(8,0);
        LocalTime close = LocalTime.of(22, 0);

        //Overlap       
        for(Appointment ap : dbData.getAllAppointment())
        {
            if(ap.getStart().isAfter(startldt) && ap.getEnd().isBefore(endldt))
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Ooops!");
                alert.setHeaderText(null);
                alert.setContentText("Sorry, Scheduling Overlaps Existing Appointment. Please Try Again!");
            
                alert.showAndWait();
                return;
            }
        }
        //Empty Textfield(s)
        if (!textfieldEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText("Some Information Seems To Be Missing...");
            alert.setContentText("Please Review & Try Again!");  
            
            alert.showAndWait();           
            return;
        }
        //Business Hrs
        if(ntst.isBefore(open) || nted.isAfter(close))
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText("Business Hours: 8:00 a.m. - 10:00 p.m. (EST), Including Weekends");
            alert.setContentText("Appointment Start/End Time Is Outside Of Business Hours, Please Review & Try Again!");  
            
            alert.showAndWait();   
            return;      
        }
       
        dbData.updateAppointment(title, description, 
               location, type, startt, endt,  
               c, u, co, i); 
        
        Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
        Scene scene = new Scene(root);
            
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();     
        
   
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException 
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Canceling...");
        alert.setHeaderText(null);
        alert.setContentText("Continue?");
        
        Optional<ButtonType> answer = alert.showAndWait();
        
        if(answer.get() == ButtonType.OK)
        {
            
           Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
           Scene scene = new Scene(root);
               
           Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
           window.setScene(scene);
           window.show();
        }
        else
        {
            System.out.println("Not Canceled.");
        }
    }

    @FXML
    private void Date(ActionEvent event) {
    }
    
    
  
    @Override
    public String toString() 
    {
        return appointment.getStart().toString();
    }
   
}
