/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbConnect;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This class extends an application that displays an Appointment Scheduling System.
 * @author lucytran
 */
public class Schedule extends Application
{
    /**
     * Display Appointment Scheduling System Login.
     * This method starts the application with the login stage. 
     * @param stage Login stage
     * @throws Exception Get class Login to load as first stage.
     */
    @Override 
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene); 
        stage.setTitle("Appointment Scheduling");    
        stage.show();  
    }
    
    /**
     * This is the main method.This method connects the application to the database where data can be accessed.
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException, Exception
    {    
       // Locale.setDefault(new Locale("fr")); //to test

        dbConnect.makeConnect();
        launch(args);
        dbConnect.closeConnect();
    }
        
}
