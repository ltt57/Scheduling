/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbConnect;
import database.dbData;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;
import model.User;

/**
 * Methods for Appointment Scheduling System.
 * This is the Main Controller class.
 * 
 * This method is used to display customers and appointments data from the database.
 * The method enables users to access the customers and appointments to be added, modified, and deleted.
 * Adding or modifying customers or appointments will return back to this window with the updated information.
 * All data will be updated in the database as well.
 * 
 * The method allows access to a report window with the view of overall information.
 * User may exit the system from this window.
 * @author lucytran
 */
public class MainController implements Initializable
{

    @FXML
    private TableView<Appointment> AppointmentTBL;
    @FXML
    private TableColumn<Appointment, Integer> AppointmentID;
    @FXML
    private TableColumn<Appointment, String> Title;
    @FXML
    private TableColumn<Appointment, String> Description;
    @FXML
    private TableColumn<Appointment, String> Location;
    @FXML
    private TableColumn<Appointment, String> Contact;
    @FXML
    private TableColumn<Appointment, String> Type;
    @FXML
    private TableColumn<Appointment, Date> Start;
    @FXML
    private TableColumn<Appointment, Date> End;
    @FXML
    private TableColumn<Appointment, String> CustomerNameList;
    @FXML
    private TableColumn<Appointment, String> UserNameList;  
    @FXML
    private RadioButton MonthRadio;
    @FXML
    private RadioButton WeekRadio;
    @FXML
    private Button AddButton;
    @FXML
    private Button EditButton;
    @FXML
    private Button DeleteButton; 
    @FXML
    private TableView<Customer> CustomerTBL;
    @FXML
    private TableColumn<Customer, String> CustomerName;
    @FXML
    private TableColumn<Customer, String> Address;
    @FXML
    private TableColumn<Customer, Integer> PostalCode;
    @FXML
    private TableColumn<Customer, Integer> PhoneNumber;
    @FXML
    private Button LogoutButton;
    @FXML
    private Label UserTime;
    @FXML
    private Button ReportButton;
    @FXML
    private RadioButton AllRadioButton;
    @FXML
    private ToggleGroup group;
    @FXML
    private TableColumn<Customer, Integer> divisionID;

    /**
     * All Customers List.
     * This list contains all the customers from the database.
     */
    private ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
    
    /**
     * All Appointments List.
     * This list contains all the appointments from the database.
     */
    private ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
    
    
    /**
     * All Appointments Existing for Customer.
     * This list contains all the appointments that exists for customer.
     */
    private ObservableList<Customer> existingA = FXCollections.observableArrayList();

    
    Appointment appointment;
    Customer customer;
    User user;
    static int index;
    int customerID;
 
    
    /**
     * This method initializes the controller for the Main window.
     * This method is used to populate and display data for customers and appointments tables.
     * Any time this window is loaded or returned to, the tables will re-populate with the appropriate most up to date information.
     * @param url N/A
     * @param rb N/A
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {  
        alertNotif();
        
        DateFormat format = DateFormat.getTimeInstance(DateFormat.DEFAULT, Locale.getDefault());
        String time = format.format(new Date());
        UserTime.setText(time);
             
      
        //Customer Table
        CustomerTBL.setItems(dbData.getAllCustomer());  //LOADED
   
        CustomerName.setCellValueFactory(new PropertyValueFactory <>("customerName"));
        Address.setCellValueFactory(new PropertyValueFactory <>("address"));
        PostalCode.setCellValueFactory(new PropertyValueFactory <>("postalCode"));
        PhoneNumber.setCellValueFactory(new PropertyValueFactory <>("phone"));
        divisionID.setCellValueFactory(new PropertyValueFactory<>("divisionID"));

        
        //Apointment Table
        AppointmentTBL.setItems(dbData.getAllAppointment());    //LOADED
            
        AppointmentID.setCellValueFactory(new PropertyValueFactory <>("appointmentID"));
        Title.setCellValueFactory(new PropertyValueFactory <>("title"));
        Description.setCellValueFactory(new PropertyValueFactory <>("description"));
        Location.setCellValueFactory(new PropertyValueFactory <>("location"));
        Type.setCellValueFactory(new PropertyValueFactory <>("type"));
        Start.setCellValueFactory(new PropertyValueFactory <>("start"));
        End.setCellValueFactory(new PropertyValueFactory <>("end"));
        Contact.setCellValueFactory(new PropertyValueFactory <>("contactName"));
        CustomerNameList.setCellValueFactory(new PropertyValueFactory<> ("customerName"));
        UserNameList.setCellValueFactory(new PropertyValueFactory<> ("userName"));
 
    }
    
    public void alertNotif()
    {        
        Appointment apt = dbData.upcoming(); 

        if(apt != null)
        {  
            String txt = String.format("Appointment ID: " + apt.getAppointmentID() + "   |   " + apt.getStart());
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Appointment Reminder!");
            alert.setHeaderText("Appointment Within 15 Minutes");
            alert.setContentText(txt);
            alert.showAndWait();
            
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Appointment Reminder!");
            alert.setHeaderText(null);
            alert.setContentText("No Upcoming Appointments Within 15 Minutes");
            alert.showAndWait();    

        }
       
    }

    @FXML
    private void ViewAllApptRB(ActionEvent event) 
    {
 
        AppointmentTBL.setItems(dbData.getAllAppointment());    //LOADED            
        AppointmentID.setCellValueFactory(new PropertyValueFactory <>("appointmentID"));
        Title.setCellValueFactory(new PropertyValueFactory <>("title"));
        Description.setCellValueFactory(new PropertyValueFactory <>("description"));
        Location.setCellValueFactory(new PropertyValueFactory <>("location"));
        Type.setCellValueFactory(new PropertyValueFactory <>("type"));
        Start.setCellValueFactory(new PropertyValueFactory <>("start"));
        End.setCellValueFactory(new PropertyValueFactory <>("end"));
        Contact.setCellValueFactory(new PropertyValueFactory <>("contactName"));         
        CustomerNameList.setCellValueFactory(new PropertyValueFactory<> ("customerName"));
        UserNameList.setCellValueFactory(new PropertyValueFactory<> ("userName"));
    
        AppointmentTBL.refresh(); 
    }
    
    @FXML
    private void Month(ActionEvent event) 
    { 
              
        AppointmentTBL.setItems(dbData.MonthTable());    
   
        AppointmentID.setCellValueFactory(new PropertyValueFactory <>("appointmentID"));
        Title.setCellValueFactory(new PropertyValueFactory <>("title"));
        Description.setCellValueFactory(new PropertyValueFactory <>("description"));
        Location.setCellValueFactory(new PropertyValueFactory <>("location"));
        Type.setCellValueFactory(new PropertyValueFactory <>("type"));
        Start.setCellValueFactory(new PropertyValueFactory <>("start"));
        End.setCellValueFactory(new PropertyValueFactory <>("end"));
        Contact.setCellValueFactory(new PropertyValueFactory <>("contactName"));         
        CustomerNameList.setCellValueFactory(new PropertyValueFactory<> ("customerName"));
        UserNameList.setCellValueFactory(new PropertyValueFactory<> ("userName"));
    
        
        AppointmentTBL.refresh();
    }

    @FXML
    private void Week(ActionEvent event) 
    {  
        AppointmentTBL.setItems(dbData.WeekTable());    
    
        AppointmentID.setCellValueFactory(new PropertyValueFactory <>("appointmentID"));
        Title.setCellValueFactory(new PropertyValueFactory <>("title"));
        Description.setCellValueFactory(new PropertyValueFactory <>("description"));
        Location.setCellValueFactory(new PropertyValueFactory <>("location"));
        Type.setCellValueFactory(new PropertyValueFactory <>("type"));
        Start.setCellValueFactory(new PropertyValueFactory <>("start"));
        End.setCellValueFactory(new PropertyValueFactory <>("end"));
        Contact.setCellValueFactory(new PropertyValueFactory <>("contactName"));         
        CustomerNameList.setCellValueFactory(new PropertyValueFactory<> ("customerName"));
        UserNameList.setCellValueFactory(new PropertyValueFactory<> ("userName"));
    
        AppointmentTBL.refresh();
    
    }

  
    @FXML
    private void AddAppointment(ActionEvent event) throws IOException 
    {   
 
        Parent root = FXMLLoader.load(getClass().getResource("AddAppointment.fxml"));
        Scene scene = new Scene(root);
  
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();  
    }

    @FXML
    private void EditAppointment(ActionEvent event) throws IOException, ParseException 
    {
       
        appointment = AppointmentTBL.getSelectionModel().getSelectedItem();
        index = allAppointments.indexOf(appointment);
  
        if (AppointmentTBL.getSelectionModel().getSelectedItem() == null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("No Appointment Selected... Please Try Again.");
            
            alert.showAndWait();
            
            return;
        }
        
       
        Parent root;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Appointment.fxml"));
        root = loader.load();
        AppointmentController controller = loader.getController();

        if(appointment != null)
        {
            controller.setAppointment(appointment); 
        }        
       
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    
        window.setScene(scene);
        window.show();   
    }

    @FXML
    private void DeleteAppointment(ActionEvent event) 
    {      
        appointment = AppointmentTBL.getSelectionModel().getSelectedItem(); 
        
        int appointmentID = appointment.getAppointmentID();
        
        String type = appointment.getType();
       
        boolean delete = false;
        
        if(appointment.getAppointmentID() == 0)
        {
            delete = false;
             
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Appointment Not Deleted...");
            alert.setHeaderText(null);          
            alert.setContentText("ERROR: No Appointment(s) Selected!");
           
            alert.showAndWait();   
        }
        else
        {
            delete = true;
     
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("DELETE");
            alert.setHeaderText("Deleting Appointment...");
            alert.setContentText("AppointmentID: "+ appointmentID + " | " + type + "  Will Be Deleted. Continue?");        
            
            alert.showAndWait(); 

            
            dbData.deleteAppointment(appointmentID);
            dbData.getAllAppointment().remove(appointment);
            
            AppointmentTBL.getItems().remove(appointment);
    
            AppointmentTBL.refresh();
            
           
        }

    }

    @FXML
    private void AddCustomer(ActionEvent event) throws IOException 
    {
      
        Parent root = FXMLLoader.load(getClass().getResource("AddCustomer.fxml"));
        
        Scene scene = new Scene(root);
  
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
             
        window.setScene(scene);
        window.show();  
  
    }

    @FXML
    private void EditCustomer(ActionEvent event) throws IOException 
    {
        customer = CustomerTBL.getSelectionModel().getSelectedItem();
        
        
        if (CustomerTBL.getSelectionModel().getSelectedItem() == null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("No Customer Selected... Please Try Again.");
            
            return;
        }
        
        dbData.getAllCustomer().add(customer);
        dbData.getAllCustomer().remove(customer);

        
        Parent root;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Customer.fxml"));
        root = loader.load();
        CustomerController controller = loader.getController();

        if(customer != null)
        {
            controller.setCustomer(customer);
        }        
       
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    
        window.setScene(scene);
        window.show();
    }

    
 

   
   /**
    * Lambda Expression: Delete Customer.
    * This method first checks if there exists an appointment for customer selected to delete.
    * The lambda expression takes the parameter of the alert button for confirmation to delete the customer.
    * It proceeds to delete the customer when the button is pressed by user.
    * The method removes the selected customer from the database and from the table.
    * The purpose of this lambda is to reduce code for higher efficiency for the functional programming. 
    */ 
    @FXML
    public void DeleteCustomer(ActionEvent event) throws SQLException 
    {
        customer = CustomerTBL.getSelectionModel().getSelectedItem();
        
        int customerID = customer.getCustomerID();

        
        if(!dbData.ExistingA(customerID)) 
        {            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Deleting Customer...");
            alert.setHeaderText("Customer Will Be Deleted.");          
            alert.setContentText("Continue?");
            
            alert.showAndWait().ifPresent((response -> {
                if(response == ButtonType.OK)
                { 
                  dbData.deleteCustomer(customerID); 
                  dbData.getAllCustomer().remove(customer);
                }
                
            }));
        
            allCustomers.remove(customer);
            CustomerTBL.getItems().remove(customer);
 
            CustomerTBL.refresh();

        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ooops!");
            alert.setHeaderText("Customer Cannot Be Deleted With Existing Appointment(s)!");          
            alert.setContentText("All Existing Appointments For Customer Must Be Removed First. Please Try Again!");
            
            alert.showAndWait();
        }
    }

    @FXML
    private void Logout(ActionEvent event) throws IOException, SQLException, Exception 
    {
        dbConnect.closeConnect();

        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
  
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();  
        
    }

    @FXML
    private void Reports(ActionEvent event) throws IOException 
    {
        Parent root = FXMLLoader.load(getClass().getResource("Report.fxml"));
        Scene scene = new Scene(root);
  
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();  
        
    }
  
}
