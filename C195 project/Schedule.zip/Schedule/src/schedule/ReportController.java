/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbData;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import model.Appointment;
import model.Contacts;

/**
 * Methods for report.
 * This class is the controller for the report.
 * This class displays an overall schedule of appointment's data for each contact.
 * The method gives a total count of customers and for each type per month.
 * @author lucytran
 */
public class ReportController implements Initializable {

    @FXML
    private TableColumn<String, Appointment> Month;
    @FXML
    private TableColumn<String, Appointment> ReportContact;
    @FXML
    private TableColumn<String, Appointment> ReportSchedule;
    @FXML
    private TableColumn<String, Appointment> Type;
    @FXML
    private TextField AllCustomerTotalTB;
    @FXML
    private Button ReturnButton;
    @FXML
    private TableView<Appointment> MonthTBL;
    @FXML
    private TableColumn<Integer, Appointment> MonthCustTotal;
    @FXML
    private TableView<Appointment> ScheduleTBL;
     @FXML
    private TableColumn<Appointment, LocalDateTime> Start;
    @FXML
    private TableColumn<Appointment, LocalDateTime> End;
    
    Appointment appointment;
    Contacts contact;
   

    /**
     * This method initializes the controller for report.
     * Sets the table for Month with appointment Type and the total number of customers for each.
     * The schedule table is populated with the appointments for each contact.
     * @param url N/A
     * @param rb N/A
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {        
        //total # of customers 
        AllCustomerTotalTB.setText(String.valueOf(dbData.allcustTotal())); 
        
                 
        //total # of appointments by month
        MonthTBL.setItems(dbData.MonthReport());
        Month.setCellValueFactory(new PropertyValueFactory <>("month"));
        MonthCustTotal.setCellValueFactory(new PropertyValueFactory <> ("total"));
        Type.setCellValueFactory(new PropertyValueFactory <>("type"));
        
      
        //contact + schedule 
        ScheduleTBL.setItems(dbData.ScheduleTable());
        ReportContact.setCellValueFactory(new PropertyValueFactory <>("contactName"));
        ReportSchedule.setCellValueFactory(new PropertyValueFactory <>("schedule"));
        Start.setCellValueFactory(new PropertyValueFactory<>("Start"));
        End.setCellValueFactory(new PropertyValueFactory<>("End"));
        
    }

    
    @FXML
    private void AllCustomerTotal(ActionEvent event) 
    { 
    }

    @FXML
    private void Return(ActionEvent event) throws IOException 
    {
        //Return to Main
        Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
        Scene scene = new Scene(root);
           
           
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();
        
    }

    @FXML
    private void Start(CellEditEvent<Appointment, String> event) {
  
    }

    @FXML
    private void End(CellEditEvent<Appointment, LocalDateTime> event) 
    {
        
    }



   
}
