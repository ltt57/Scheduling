/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbData;
import database.dbUser;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Appointment;
import model.User;

/**
 * Methods for logging in.
 * This class is the controller for logging into the system.
 * This method is used for users to enter information for login.
 * Once data is provided by user, the application allows or denies access to the system.
 * @author lucytran
 */
public class LoginController implements Initializable
{

    @FXML
    private Button LoginButton;
    @FXML
    private Button ExitButton;
    @FXML
    private TextField UserIDTB;
    @FXML
    private TextField PasswordTB;
    @FXML
    private Label UserLocationLabel;
    @FXML
    private Label idL;
    @FXML
    private Label pwL;

    static ObservableList<User> userLog = FXCollections.observableArrayList();
 
    private String errorH;
    private String errorTl;
    private String errorTx;
    
    
    ResourceBundle bundle = ResourceBundle.getBundle("schedule/Lang", Locale.getDefault()); 
    User user;
   
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
       
        UserLocationLabel.setText(ZoneId.systemDefault().toString());
  
        Locale france = new Locale("fr", "FR");
        Locale english = new Locale("en", "EN");

        if(Locale.getDefault().getLanguage().equals("en") 
                || Locale.getDefault().getLanguage().equals("fr"))
        {
            idL.setText(bundle.getString("userID"));
            pwL.setText(bundle.getString("password"));
            LoginButton.setText(bundle.getString("login"));
            ExitButton.setText(bundle.getString("exit"));
            
            errorTl = bundle.getString("errorTitle");
            errorH = bundle.getString("errorHeader");
            errorTx = bundle.getString("errorText");


            System.out.println(bundle.getString("language"));
        }

 
    }
   /**
     * Method to set user.
     * This method is to set the current user of the program.
     * @param user User
     */
    public void setUser(User user)
    {
        this.user = user;
    }
    
   
    @FXML
    public void Login(ActionEvent event) throws IOException, SQLException, ClassNotFoundException 
    { 
        String userName = UserIDTB.getText();
        String password = PasswordTB.getText();
        
        boolean valid = dbUser.login(userName, password);
    
        if(valid)
        {
            Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
            Scene scene = new Scene(root);
  
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show(); 
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(errorTl);
            alert.setHeaderText(errorH);
            alert.setContentText(errorTx);
            alert.showAndWait();
        }
       
    }

    @FXML
    private void UserID(ActionEvent event) {
    }

    @FXML
    private void Password(ActionEvent event) {
    }
 
    @FXML
    private void Exit(ActionEvent event) 
    {
        Platform.exit();
    }
    
    
}
