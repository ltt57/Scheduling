/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbData;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Countries;
import model.FirstLevelDivisions;

/**
 * Methods for adding a customer.
 * This class is the controller for adding a customer.
 * This method is used to add a new customer to the database.
 * Once data is provided by user, the data can be saved and displayed on the Main page.
 * @author lucytran
 */
public class AddCustomerController implements Initializable
{
    @FXML
    private Label CustomerLabel;
    @FXML
    private TextField CustomerNameTB;
    @FXML
    private TextField PhoneTB;
    @FXML
    public ComboBox<Countries> CountryTB;
    @FXML
    private TextField Address1TB;
    @FXML
    private ComboBox<FirstLevelDivisions> StateComboBox;
    @FXML
    private TextField PostalCodeTB;
    @FXML
    private TextField CustomerIDTB;
    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
    
    
    /**
     * This initializes the controller for adding a customer.
     * This method sets the title for the page and disables the ID text field.
     * This method gives the list of countries to be selected in a combo-box.
     * @param url N/A
     * @param rb N/A
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        CustomerLabel.setText("Add Customer");
        CustomerIDTB.setDisable(true);
        
        CountryTB.setItems(dbData.CountryList());
  
       // Country(null);     
     
    }

    @FXML
    private void CustomerName(ActionEvent event) {
    }

    @FXML
    private void PhoneNumber(ActionEvent event) {
    }

    @FXML
    private void Country(ActionEvent event) 
    {  
        Countries c = CountryTB.getValue();
        
      
        
        StateComboBox.setItems(dbData.DivisionsList(c.getCountryID()));
    }

    @FXML
    private void Address1(ActionEvent event) 
    {
        Address1TB.setPromptText("ex.: 123 Apple Street, City");
    }


    @FXML
    private void State(ActionEvent event) 
    {        
    }

    @FXML
    private void PostalCode(ActionEvent event) {
    }

    @FXML
    private void CustomerID(ActionEvent event) {
    }

     /**
     * Method to check for empty text fields.
     * This method checks for any empty text fields,
     * If the field is empty, the method highlights the missing component(s).
     * @return textfieldEmpty
     */
    private boolean textfieldEmpty()
    {
        boolean validTF = true;
        
        if(CustomerNameTB.getText().isEmpty())
        {
            validTF = false;
            CustomerNameTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
         
        
        if(Address1TB.getText().isEmpty())
        {
            validTF = false;
            Address1TB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
       
        if(PostalCodeTB.getText().isEmpty())
        {
            validTF = false;
            PostalCodeTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
        
        if(PhoneTB.getText().isEmpty())
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Phone Number!");  
            
            alert.showAndWait();
        }
        if(StateComboBox.getValue() == null)
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include State!");  
            
            alert.showAndWait();   
        }
        if(CountryTB.getValue() == null)
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Country!");  
            
            alert.showAndWait();
        }
        
       
        return validTF;    
    }
    
    @FXML
    private void Save(ActionEvent event) throws IOException
    {
        String customerName = CustomerNameTB.getText();
        String address = Address1TB.getText();
        String postalCode = PostalCodeTB.getText();
        String phone = PhoneTB.getText();
        FirstLevelDivisions ff = StateComboBox.getValue();
        
        if(!textfieldEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Some information seems to be missing... Please try again!");  
            
            alert.showAndWait(); 
        
            return;
        }
        
        dbData.addCustomer(customerName, address, postalCode, phone, ff);

        Parent root = FXMLLoader.load(getClass().getResource("Main.fxml")); 
        Scene scene = new Scene(root); 
                     
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();   
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException 
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Canceling...");
        alert.setHeaderText(null);
        alert.setContentText("Continue?");
        
        Optional<ButtonType> answer = alert.showAndWait();
        
        if(answer.get() == ButtonType.OK)
        {
            
           Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
           Scene scene = new Scene(root);
           
           
           Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
           window.setScene(scene);
           window.show();   
        }
       
    }
}   
