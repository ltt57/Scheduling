/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import database.dbData;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Countries;
import model.Customer;
import model.FirstLevelDivisions;

/**
 * Methods for modifying a customer.
 * This class is the controller for modifying a customer.
 * This class provides implementations and methods for selected customer from the Customer table.
 * The selected customer is then modifiable through this controller window.
 * @author lucytran
 */
public class CustomerController implements Initializable
{
  @FXML
    private Label CustomerLabel;
    @FXML
    private TextField CustomerNameTB;
    @FXML
    private TextField PhoneTB;
    @FXML
    private ComboBox<Countries> CountryTB;
    @FXML
    private TextField Address1TB;
    @FXML
    private ComboBox<FirstLevelDivisions> StateComboBox;
    @FXML
    private TextField PostalCodeTB;
    @FXML
    private TextField CustomerIDTB;
    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
     
  
    Customer customer;
    
  /**
   * This initializes the controller fo modifying a customer.
   * This method sets the title for the page and disables the ID text field.
   * @param url
   * @param rb 
   */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    { 
        CustomerLabel.setText("Edit Customer");
        CustomerIDTB.setDisable(true);

    }
    
     /**
     * This method sets a customer.
     * This method is used to set the selected customer data.
     * @param customer  This is customer that is being modified.
     */
    public void setCustomer(Customer customer)
    {
        this.customer = customer;
        

        CustomerIDTB.setText(Integer.toString(customer.getCustomerID()));
        CustomerNameTB.setText(customer.getCustomerName());
        PhoneTB.setText(customer.getPhone());
     
        Address1TB.setText(customer.getAddress());
        PostalCodeTB.setText(customer.getPostalCode()); 
        CountryTB.setItems(dbData.CountryList());

        
        //cannot set state list until country
        //steps..
        //1. set item in country combo
        //2. set selected country 
        //3. set item based selected countryid in division combo
        //4. set selected division

        //find matching country w/ id in list (2)
   
        
        for(Countries c : CountryTB.getItems())
        {
            if(c.getCountryID() == customer.getCountryID())
            {
                CountryTB.setValue(c);
                break;
            }    
        }
        
        Country(null); 
        
        for(FirstLevelDivisions f : StateComboBox.getItems())
        {
            if(f.getDivisionID() == customer.getDivisionID())
            {
                StateComboBox.setValue(f);
                break;
            }
        } 
        
    }
  
   
    
    @FXML
    private void CustomerName(ActionEvent event) {
    }

    @FXML
    private void PhoneNumber(ActionEvent event) {
    }

    @FXML
    private void Country(ActionEvent event)
    {
        Countries c = CountryTB.getValue();
   
        StateComboBox.setItems(dbData.DivisionsList(c.getCountryID()));
    }

    @FXML
    private void Address1(ActionEvent event) 
    {
        Address1TB.setPromptText("ex.: 123 Apple Street, City");
    }


    @FXML
    private void State(ActionEvent event) 
    {
    }

    @FXML
    private void PostalCode(ActionEvent event) {
    }

    @FXML
    private void CustomerID(ActionEvent event) {
    }

     /**
     * Method to check for empty text fields.
     * This method checks for any empty text fields,
     * If the field is empty, the method highlights the missing component(s).
     * @return textfieldEmpty
     */
    private boolean textfieldEmpty()
    {
        boolean validTF = true;
        
        if(CustomerNameTB.getText().isEmpty())
        {
            validTF = false;
            CustomerNameTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
         
        
        if(Address1TB.getText().isEmpty())
        {
            validTF = false;
            Address1TB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
       
        if(PostalCodeTB.getText().isEmpty())
        {
            validTF = false;
            PostalCodeTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Textfield is empty!");  
            
            alert.showAndWait();
        }
        
        if(PhoneTB.getText().isEmpty())
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Phone Number!");  
            
            alert.showAndWait();
        }
        if(StateComboBox.getValue() == null)
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include State!");  
            
            alert.showAndWait();   
        }
        if(CountryTB.getValue() == null)
        {
            validTF = false;
            PhoneTB.setStyle("-fx-text-box-border: #B22222; -fx-focus-color: #B22222;");
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Include Country!");  
            
            alert.showAndWait();
        }
        
       
        return validTF;   
    }
      
    /**
     * Lambda Expression: Check for missing data.
     * This method is to save the updated information for the selected customer being modified.
     * The purpose of this method where the expression resides searches for missing data a user must enter.
     * The lambda expression takes the user input when text field(s) is alerted as empty and returns the response for the alert.
     * The expression is beneficial because it reduces code lines and promotes efficiency. 
     * @param event
     * @throws IOException 
     */
    @FXML
    public void Save(ActionEvent event) throws IOException 
    {    
        int customerID = Integer.parseInt(CustomerIDTB.getText());  
        
        String customerName = CustomerNameTB.getText();
        String address = Address1TB.getText();
        String postalCode = PostalCodeTB.getText();
        String phone = PhoneTB.getText();
        
        FirstLevelDivisions state = StateComboBox.getValue();

        if(!textfieldEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Some information seems to be missing... Please try again!");  
            
            alert.showAndWait().ifPresent((response -> {
                System.out.println("Some information is missing in edit customer");
                

            }));          
            
            return;
        }
       
        else
        {   
            dbData.updateCustomer(customerID, customerName, address, postalCode, phone, state);
        }
       

        Parent root = FXMLLoader.load(getClass().getResource("Main.fxml")); 
        Scene scene = new Scene(root);
           
           
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
        window.setScene(scene);
        window.show();
        
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException 
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Canceling...");
        alert.setHeaderText(null);
        alert.setContentText("Continue?");
        
        Optional<ButtonType> answer = alert.showAndWait();
        
        if(answer.get() == ButtonType.OK)
        {
            Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
            Scene scene = new Scene(root);
           
           
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
  
        }
        else
        {
            System.out.println("Not Canceled.");
        }
    }

    
}
