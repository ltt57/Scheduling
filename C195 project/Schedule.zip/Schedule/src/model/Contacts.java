/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * Methods for contacts data.
 * This method allows access for the contact ID, name, and email.
 * @author lucytran
 */
public class Contacts 
{
    private int contactID;
    private String contactName;
    private String email;
        
    /**
     * 
     * @param contactID Contact ID
     * @param contactName Contact Name
     * @param email Email
     */
    public Contacts(int contactID, String contactName, String email)
    {
        this.contactID = contactID;
        this.contactName = contactName;
        this.email = email;
    
    }
    
    /**
     * 
     * @param contactName contactName
     */
    public Contacts(String contactName)
    {
        this.contactName = contactName;
    }
    
    /**
     * 
     * @param contactName contactName
     * @param email email
     */
    public Contacts(String contactName, String email)
    {
        this.contactName = contactName;
        this.email = email;
    }
    
    /**
     * 
     * @return The contact ID for contact.
     */
    public int getContactID()
    {
       return contactID;
    }
    
    /**
     * 
     * @return The contact name for contact.
     */
    public String getContactName()
    {
        return contactName;
    }
    
    /**
     * 
     * @return The email for contact.
     */
    public String getEmail()
    {
        return email;
    }
    
    /**
     * 
     * @param contactID Set the contact ID for contact.
     */
    public void setContactID(int contactID)
    {
        this.contactID = contactID;
    }
    
    /**
     * 
     * @param contactName Set the contact name for contact.
     */
    public void setContactName(String contactName)
    {
        this.contactName = contactName;
    }
    
    /**
     * 
     * @param email Set the email for contact.
     */
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    /**
     * Method to String contact name.
     * This method allows contact name for contact to be listed in a combo-box. 
     * @return contactName
     */
    @Override 
    public String toString()
    {
        return(contactName);
      
    }
    
  
}
