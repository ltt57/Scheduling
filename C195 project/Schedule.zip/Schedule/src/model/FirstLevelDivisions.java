/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Methods for first level divisions data.
 * This method allows access for first level divisions.
 * @author lucytran
 */
public class FirstLevelDivisions
{
    private ObservableList<FirstLevelDivisions> divisionList = FXCollections.observableArrayList();    
    
    private int divisionID;
    private String division;
    

    private int countryID;
    
    /**
     * 
     * @param division Division
     */
    public FirstLevelDivisions(String division)
    {
        this.division = division;
    }
    
    /**
     * 
     * @param divisionID Division ID
     */
    public FirstLevelDivisions(int divisionID)
    {
        this.divisionID = divisionID;
    }
    
    /**
     * 
     * @param divisionID Division ID
     * @param division Division
     * @param countryID Country ID
     */
    public FirstLevelDivisions(int divisionID, String division, int countryID)
    {
        this.divisionID = divisionID;
        this.division = division;
        this.countryID = countryID;     
    }
            
    /**
     * 
     * @return The division ID for first level division.
     */
    public int getDivisionID()
    {
        return divisionID;
    }
    
    /**
     * 
     * @return The division for first level division.
     */
    public String getDivision()
    {
        return division;
    }
    
    
    /**
     * 
     * @return The country ID for first level division.
     */
    public int getCountryID()
    {
        return countryID;
    }
    
    /**
     * 
     * @param countryID Set the country ID for first level division.
     */
    public void setCountryID(int countryID)
    {
        this.countryID = countryID;
    }
    
    /**
     * 
     * @param divisionID Set the division ID for first level division.
     */
    public void setDivisionID(int divisionID)
    {
        this.divisionID = divisionID;
    }
    
    /**
     * 
     * @param division Set the division for first level division.
     */
    public void setDivision(String division)
    {
        this.division = division;
    }
    

    /**
     * Method for list of divisions.
     * This method contains list of divisions.
     * @return divisionList
     */
    public ObservableList<FirstLevelDivisions> getDivisionList()
    {
        return divisionList;
    }
    
    /**
     * Method to String division.
     * This method allows division for first level division to be listed in a combo-box.
     * @return division
     */
    @Override 
    public String toString()
    {
        return(division);
      
    }
}
