/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Methods for User class.
 * This User class represents an entity.
 * This method allows access for users.
 * @author lucytran
 */
public class User
{
    private ObservableList<User> userList = FXCollections.observableArrayList();
    private int userID;
    private String userName;
    private String password;
    
    public User() {}
  
 
    /**
    * 
    * @param userName User Name
    * @param password Password
    */
    public User(String userName, String password)
    {
        this.userName = userName;
        this.password = password;        
    }
    
    /**
     * 
     * @param userID User ID
     * @param userName User Name
     * @param password Password
     */
    public User(int userID, String userName, String password)
    {
        this.userID = userID;
        this.userName = userName;
        this.password = password;    
    }

    /**
     * 
     * @param userName User Name
     */
    public User(String userName)
    {
        this.userName = userName;
    }
    
    /**
     * 
     * @param userID User ID
     */
    public User(int userID)
    {
        this.userID = userID;
    }
  
    /**
     * 
     * @return The user ID for user.
     */
    public int getUserID()
    {
        return userID;
    }
    
    /**
     * 
     * @return The user name for user.
     */
    public String getUserName()
    {
        return userName;
    }
    
    /**
     * 
     * @return The password for user.
     */
    public String getPassword()
    {
        return password;
    }
    
   
 
    /**
     * 
     * @param userID Set user ID for user.
     */
    public void setUserID(int userID)
    {
       this.userID = userID;
    }
    
    /**
     * 
     * @param userName Set user name for user.
     */
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    
    /**
     * 
     * @param password Set password for user.
     */
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    
    /**
     * Method for list of users.
     * This method contains list of users.
     * @return userList
     */
    public ObservableList<User> getUserList()
    {
        return userList;
    }
  
    /**
     * Method to String user name.
     * This method allows user name for user to be listed in a combo-box.
     * @return userName
     */
    @Override 
    public String toString()
    {
        return(userName);
      
    }
   
  
}
