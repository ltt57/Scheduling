/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * Methods for obtaining, adding, or removing customers from the database.
 * This method allows customer data to be accessed.
 * Using this method, a customer can be created, modified, and deleted.
 * @author lucytran
 */
public class Customer 
{
 
    private int customerID;
    private String customerName;
    private String address;
    private String postalCode;
    private String phone;
   
    private int divisionID; // in both constructors 
    
    private int countryID;
    
    /**
     * 
     * @param customerID Customer ID
     * @param customerName Customer Name
     * @param address Address
     * @param postalCode Postal Code
     * @param phone Phone
     * @param divisionID Division ID
     * @param countryID Country ID
     */
    public Customer(int customerID, String customerName, String address, String postalCode, String phone, int divisionID, int countryID)
    { 
        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.divisionID = divisionID;
        this.countryID = countryID;
    }

    /**
     * 
     * @return The customer's Division ID.
     */
    public int getDivisionID()
    {
        return divisionID;
    }
    
    /**
     * 
     * @param divisionID Set division ID for customer.
     */
    public void setDivisionID(int divisionID)
    {
        this.divisionID = divisionID;
    }
    
    /**
     * 
     * @return The country ID for customer.
     */
    public int getCountryID()
    {
        return countryID;
    }
    
    /**
     * 
     * @param countryID Set country ID for customer.
     */
    public void setCountryID(int countryID)
    {
        this.countryID = countryID;
    }
    
    /**
     * 
     * @return The customer ID for customer.
     */
    public int getCustomerID()
    {
        return customerID;
    }
    
    /**
     * 
     * @return The customer name for customer.
     */
    public String getCustomerName()
    {
        return customerName;
    }
    
    /**
     * 
     * @return The address for customer.
     */
    public String getAddress()
    {
        return address;
    }
    
    /**
     * 
     * @return The postal code for customer.
     */
    public String getPostalCode()
    {
        return postalCode;
    }
    
    /**
     * 
     * @return The phone number for customer.
     */
    public String getPhone()
    {
        return phone;
    }
 
    
    /**
     * 
     * @param customerID Set the customer ID for customer.
     */
    public void setCustomerID(int customerID)
    {
        this.customerID = customerID;
    }
    
   /**
    * 
    * @param customerName Set the customer name for customer.
    */
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    
    /**
     * 
     * @param address Set the address for customer.
     */
    public void setAddress(String address)
    {
        this.address = address;
    }
     
    /**
     * 
     * @param postalCode Set the postal code for customer.
     */
    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }
   
    /**
     * 
     * @param phone Set the phone number for customer.
     */
    public void setPhone(String phone)
    {
        this.phone = phone;
    }
    
 
    /**
     * Method Strings customer name for customer.
     * This method allows customer name for customer to be listed in a combo-box.
     * @return customerName
     */
    @Override 
    public String toString()
    {
        return(customerName);  
    }
   
    
}
               


