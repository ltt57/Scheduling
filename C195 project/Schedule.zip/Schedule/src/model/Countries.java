/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Methods for Countries class.
 * @author lucytran
 */
public class Countries 
{
    private ObservableList<Countries> countryList = FXCollections.observableArrayList();
    
    private int countryID;
    private String country;
  
    
    /**
     * @param country Country
     */
    public Countries(String country)
    {  
        this.country = country;
    }
    
    /**
     * 
     * @param countryID CountryID
     * @param country Country
     */
    public Countries(int countryID, String country) 
    {
        this.countryID = countryID;
        this.country = country;
    }
    
    
    /**
     * 
     * @return countryID
     */
    public int getCountryID()
    {
        return countryID;
    }
    
    /**
     * 
     * @return country
     */
    public String getCountry()
    {
        return country;
    }
    
    /**
     * 
     * @param countryID Set the countryID for country
     */
    public void setCountryID(int countryID)
    {
        this.countryID = countryID;
    }
    
    /**
     * 
     * @param country 
     */
    public void setCountry(String country)
    {
        this.country = country;
    }
    
    /**
     * 
     * @return countryList
     */
    public ObservableList<Countries> getCountryList()
    {
        return countryList;
    }
    
    /**
     * Method to String country.
     * This method allows countries to be listed in a combo-box.
     * @return 
     */
    @Override 
    public String toString()
    {
        return(country);
      
    }
}
