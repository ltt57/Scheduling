/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDateTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Methods for obtaining, adding, or removing appointments from the database.
 * This method allows appointment data to be accessed.
 * Using this method, an appointment can be created, modified, and deleted.
 * @author lucytran
 */
public class Appointment
{
    private ObservableList<Appointment> appointmentList = FXCollections.observableArrayList();

    
    private int appointmentID;
    
    private String contactName;
    private String customerName;
    private String userName;
    
    private String title;
    private String description;
    private String location;
    private String type;
    
    private LocalDateTime start;
    private LocalDateTime end;
    
    private String month;
    private int total;
   
    private String schedule;
    
    private int customerID;
    private int userID;
    private int contactID;
   
    /**
     * 
     * @param appointmentID
     * @param title
     * @param description
     * @param location
     * @param type
     * @param start
     * @param end
     * @param customerID 
     */
    public Appointment(int appointmentID, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, int customerID)
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;

        this.start = start;
        this.end = end;
        this.customerID = customerID;
    }

    /**
     * 
     * @param appointmentID Appointment ID
     * @param title Title
     * @param description Description
     * @param location Location
     * @param type Type
     * @param start Start date and time
     * @param end End date and time
     * @param contactName Contact Name
     * @param customerName Customer Name
     * @param userName User Name
     */
    public Appointment(int appointmentID, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, String contactName, String customerName, String userName)
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        
        this.start = start;
        this.end = end;
        this.contactName = contactName;
        this.customerName = customerName;
        this.userName = userName;  
    }
    
    /**
    /**
     * 
     * @param appointmentID Appointment ID
     * @param title Title
     * @param description Description
     * @param location Location
     * @param type Type
     * @param start Start date and time
     * @param end End date and time
     * @param customerID Customer ID
     * @param userID User ID
     * @param contactID Contact ID
     */
    public Appointment(int appointmentID, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, int customerID, int userID, int contactID)
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        
        this.start = start;
        this.end = end;
        this.contactID = contactID;
        this.customerID = customerID;
        this.userID = userID;  
    }
    
    /**
     * 
     * @param appointmentID Appointment ID
     * @param title Title
     * @param description Description
     * @param location Location
     * @param type Type
     * @param start Start date and time
     * @param end End date and time
     * @param customerID Customer ID
     * @param contactName Contact Name
     */
    public Appointment(int appointmentID, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, int customerID, String contactName)
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customerID = customerID;
        this.contactName = contactName;
    }
      
    /**
     * @param schedule Schedule
     * @param contactName Contact Name
     * @param start
     * @param end
     */
    public Appointment(String schedule, String contactName, LocalDateTime start, LocalDateTime end)
    {
        this.schedule = schedule;
        this.contactName = contactName;
        this.start = start;
        this.end = end;    
    }
 
    /**
     * 
     * @param type The type of appointment
     */
    public Appointment(String type)
    {
        this.type = type;
    }
    
    /**
     * 
     * @param customerID The appointment Customer ID
     */
    public Appointment(int customerID)
    {
        this.customerID = customerID;
    }

    public Appointment(int appointmentID, LocalDateTime start)
    {
        this.appointmentID = appointmentID;
        this.start = start;
    }
    
    
    /**
     * 
     * @param month Month
     * @param type Type
     * @param total Total Customers
     */
    public Appointment(String month, String type, int total)
    {
        this.month = month;
        this.total = total;
        this.type = type;
    }
    
    /**
     * @return The schedule for appointments.
     */
    public String getSchedule()
    {
        return schedule;
    }
    
    /**
     * @param schedule Set the schedule for appointments.
     */
    public void setSchedule(String schedule)
    {
        this.schedule = schedule;
    }
    
    /**
     * 
     * @return The total number of customers.
     */
    public int getTotal()
    {
        return total;
    }
    
    /**
     * @param total Set the total number of customers.
     */
    public void setTotal(int total)
    {
        this.total = total;
    }
    
    /**
     * 
     * @return The month for appointment.
     */
    public String getMonth()
    {
        return month;
    }
    
    /**
     * 
     * @param month Set the month for appointment.
     */
    public void setMonth(String month)
    {
        this.month = month;
    }
   
    
    /**
     * @return The appointment's ID.
     */
    public int getAppointmentID()
    {
        
        return appointmentID;
    }
    
    /**
     * @return The title for appointment.
     */
    public String getTitle()
    {
        return title;
    }
    
    /**
     * 
     * @return The description for appointment.
     */
    public String getDescription()
    {
        return description;
    }
    
    /**
     * 
     * @return The customer ID for appointment.
     */
    public int getCustomerID()
    {
        return customerID;
    }
    /**
     * 
     * @return The location for appointment.
     */
    public String getLocation()
    {
        return location;
    }

    /**
     * 
     * @return The contact name for appointment.
     */
    public String getContactName()
    {
        
        return contactName;
    }
    
    /**
     * 
     * @return The type of appointment.
     */
    public String getType()
    {
        return type;
    }
    
    /**
     * 
     * @return The start date and time for appointment.
     */
    public LocalDateTime getStart()
    {
        return start;
    }

    /**
     * 
     * @return The end date and time for appointment.
     */
    public LocalDateTime getEnd()
    {
        return end;
    }
    
    /**
     * 
     * @return The customer name for appointment.
     */
    public String getCustomerName()
    {
        return customerName;
    }
    
    /**
     * 
     * @return The user name for appointment.
     */
    public String getUserName()
    {
        return userName;
    }
    
    /**
     * 
     * @param start Set the start date and time for appointment.
     */
    public void setStart(LocalDateTime start)
    {
        this.start = start;
    }
    
    /**
     * 
     * @param end Set the end date and time for appointment.
     */
    public void setEnd(LocalDateTime end)
    {
        this.end = end;
    }
   
    /**
     * 
     * @param appointmentID Set the appointment ID for appointment.
     */
    public void setAppointmentID(int appointmentID)
    {
        this.appointmentID = appointmentID;
    }
    
    /**
     * 
     * @param title Set the title for appointment.
     */
    public void setTitle(String title)
    {
        this.title = title;
    }
    
    /**
     * 
     * @param customerID Set the customer ID for appointment.
     */
    public void setCustomerID(int customerID)
    {
       this.customerID = customerID;
    }
    
    /**
     * 
     * @param description Set the description for appointment.
     */
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    /**
     * 
     * @param location Set the location for appointment.
     */
    public void setLocation(String location)
    {
        this.location = location;
    }
    
    /**
     * 
     * @param contactName Set the contact name for appointment.
     */
    public void setContactName(String contactName)
    {
        this.contactName = contactName;
    }
    
    /**
     * 
     * @param type Set the type of appointment.
     */
    public void setType(String type)
    {
        this.type = type;
    }
    
    /**
     * 
     * @param customerName Set the customer name for appointment.
     */
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    
    /**
     * 
     * @param userName Set the user name for appointment.
     */
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    
    /**
     * 
     * @return The list of appointments.
     */
    public ObservableList<Appointment> getAppointmentList()
    {
        return appointmentList;
    }
    
    /**
     * Method Strings types of appointment.
     * This method allows types for appointment to be listed in a combo-box.
     * @return appointment type
     */
    @Override 
    public String toString()
    {
        return(type);
    
    } 
    
    
    
}